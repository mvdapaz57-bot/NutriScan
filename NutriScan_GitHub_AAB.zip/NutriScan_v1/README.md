# NutriScan — v1.0 base de desenvolvimento

Esta versão avança o protótipo para uma base Android funcional com:
- Jetpack Compose
- navegação
- preview de câmera com CameraX
- tela de análise
- modelo de dados nutricional
- histórico demonstrativo
- metas demonstrativas

## O que ainda exige integração externa
O reconhecimento automático por IA e os valores nutricionais reais precisam de um serviço/modelo e uma fonte de dados nutricionais. A tela está preparada para receber esse resultado, mas não finge que a IA já está conectada.

## Abrir
Abra a pasta no Android Studio e sincronize o Gradle.

## Release
Depois de configurar assinatura de produção, gere um Android App Bundle (.aab) pelo Android Studio.

## Próximo desenvolvimento
- captura de foto real
- endpoint de visão/IA
- banco nutricional
- persistência local
- autenticação
- notificações
- testes
- política de privacidade e materiais da Play Store
