package com.nutriscan.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.compose.*

data class Food(val name:String,val calories:Int,val protein:Int,val carbs:Int,val fat:Int,val fiber:Int)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NutriScanApp() }
    }
}

@Composable
fun NutriScanApp() {
    val nav=rememberNavController()
    MaterialTheme {
        Scaffold(bottomBar={
            NavigationBar {
                listOf("Início" to "home","Scan" to "scan","Histórico" to "history","Metas" to "goals").forEach { (label,route) ->
                    NavigationBarItem(false,{nav.navigate(route)},icon={},label={Text(label)})
                }
            }
        }) { p ->
            NavHost(nav,"home",Modifier.padding(p)) {
                composable("home"){HomeScreen()}
                composable("scan"){ScanScreen()}
                composable("history"){HistoryScreen()}
                composable("goals"){GoalsScreen()}
            }
        }
    }
}

@Composable fun HomeScreen(){
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        Text("NutriScan",style=MaterialTheme.typography.headlineLarge)
        Text("Analise suas refeições e acompanhe sua nutrição.")
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){
            Text("Resumo de hoje",style=MaterialTheme.typography.titleLarge)
            Text("Calorias: 0 kcal"); Text("Proteínas: 0 g"); Text("Água: 0 ml")
        }}
        Text("Dica: confira sempre o resultado da IA antes de registrar uma refeição.")
    }
}

@Composable fun ScanScreen(){
    var analyzed by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Scan",style=MaterialTheme.typography.headlineLarge)
        CameraPreview(Modifier.fillMaxWidth().height(330.dp))
        Button(onClick={analyzed=true},Modifier.fillMaxWidth()){Text("Analisar refeição")}
        if(analyzed) Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
            Text("Resultado estimado",style=MaterialTheme.typography.titleLarge)
            Text("Arroz, feijão e frango")
            Text("520 kcal  •  Proteínas 34 g")
            Text("Carboidratos 62 g  •  Gorduras 14 g")
            Text("Fibras 9 g")
            Text("Confirme/corrija o alimento antes de salvar.")
        }}
    }
}

@Composable fun CameraPreview(modifier:Modifier){
    val context=LocalContext.current
    val previewView=remember{PreviewView(context)}
    LaunchedEffect(Unit){
        val future=ProcessCameraProvider.getInstance(context)
        future.addListener({
            val provider=future.get()
            val preview=androidx.camera.core.Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            provider.unbindAll()
            provider.bindToLifecycle(context as androidx.lifecycle.LifecycleOwner,CameraSelector.DEFAULT_BACK_CAMERA,preview)
        },ContextCompat.getMainExecutor(context))
    }
    AndroidView({previewView},modifier)
}

@Composable fun HistoryScreen(){
    val foods=listOf(Food("Arroz, feijão e frango",520,34,62,14,9),Food("Banana",105,1,27,0,3))
    LazyColumn(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Text("Histórico",style=MaterialTheme.typography.headlineLarge)}
        items(foods.size){i->val f=foods[i];Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){
            Text(f.name,style=MaterialTheme.typography.titleMedium)
            Text("${f.calories} kcal • P ${f.protein}g • C ${f.carbs}g • G ${f.fat}g • F ${f.fiber}g")
        }}}
    }
}

@Composable fun GoalsScreen(){
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Text("Metas",style=MaterialTheme.typography.headlineLarge)
        Text("Calorias — 2.000 kcal"); LinearProgressIndicator({0f},Modifier.fillMaxWidth())
        Text("Proteínas — 120 g"); LinearProgressIndicator({0f},Modifier.fillMaxWidth())
        Text("Água — 2.000 ml"); LinearProgressIndicator({0f},Modifier.fillMaxWidth())
    }
}
